package com.example.TimesheetMicroService.model;

import javax.persistence.*;

@Entity
@Table(name = "timesheets")
public class Timesheet {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "projectname")
	private String projectname;

	@Column(name = "status")
	private String status;

	@Column(name = "plannedeffort")
    private String plannedeffort;
    
    @Column(name = "loggedeffort")
    private String loggedeffort;
    
    @Column(name = "billablehours")
	private String billablehours;

	public Timesheet() {

	}

	public Timesheet(String projectname, String status, String plannedeffort, String loggedeffort, String billablehours) {
        this.projectname = projectname;
        this.status = status;
        this.plannedeffort = plannedeffort;
        this.loggedeffort = loggedeffort;
        this.billablehours = billablehours;
	}

	public long getId() {
		return id;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
    }
    
    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
    }
    
    public String getPlannedeffort() {
		return plannedeffort;
	}

	public void setPlannedeffort(String plannedeffort) {
		this.plannedeffort = plannedeffort;
    }
    
    public String getLoggedeffort() {
		return loggedeffort;
	}

	public void setLoggedeffort(String loggedeffort) {
		this.loggedeffort = loggedeffort;
    }
    
    public String getBillablehours() {
		return billablehours;
	}

	public void setBillablehours(String billablehours) {
		this.billablehours = billablehours;
	}

	

	@Override
	public String toString() {
		return "Timesheet [id=" + id + ", projectname=" + projectname + ",status=" + status + ",plannedeffort=" + plannedeffort + ", loggedeffort =" + loggedeffort + ", billablehours =" + billablehours + " ]";
	}
}