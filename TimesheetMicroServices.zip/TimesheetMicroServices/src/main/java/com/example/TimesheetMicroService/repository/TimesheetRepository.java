package com.example.TimesheetMicroService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TimesheetMicroService.model.Timesheet;

public interface TimesheetRepository extends JpaRepository<Timesheet, Long> {
  //List<Employee> findByPublished(boolean published);
  List<Timesheet> findByProjectnameContaining(String projectname);
}