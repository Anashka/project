package com.example.EmployeeMicroService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeMicroService.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
  //List<Employee> findByPublished(boolean published);
  List<Employee> findByFirstnameContaining(String firstname);
}