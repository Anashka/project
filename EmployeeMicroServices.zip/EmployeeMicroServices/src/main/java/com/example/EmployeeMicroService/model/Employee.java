package com.example.EmployeeMicroService.model;

import javax.persistence.*;

@Entity
@Table(name = "employees")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "firstname")
	private String firstname;

	@Column(name = "lastname")
	private String lastname;

	@Column(name = "emailid")
    private String emailid;
    
    @Column(name = "phno")
	private String phno;

	public Employee() {

	}

	public Employee(String firstname, String lastname, String emailid, String phno) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.emailid = emailid;
        this.phno = phno;
	}

	public long getId() {
		return id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
    }
    
    public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
    }
    
    public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
    }
    
    public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	

	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstname=" + firstname + ",lastname=" + lastname + ",emailid=" + emailid + ", phno =" + phno + " ]";
	}
}