import { Component, OnInit } from '@angular/core';
import { TimesheetService } from 'src/app/services/timesheet.service';

@Component({
  selector: 'app-timesheets-list',
  templateUrl: './timesheets-list.component.html',
  styleUrls: ['./timesheets-list.component.css']
})
export class TimesheetsListComponent implements OnInit {

  timesheets: any;
  currentTimesheet = null;
  currentIndex = -1;
  projectname = '';

  constructor(private timesheetService: TimesheetService) { }

  ngOnInit(): void {
    this.retrieveTimesheets();

  }

  retrieveTimesheets() {
    this.timesheetService.getAll()
      .subscribe(
        data => {
          this.timesheets = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrieveTimesheets();
    this.currentTimesheet = null;
    this.currentIndex = -1;
  }

  setActiveTimesheet(timesheet, index) {
    this.currentTimesheet = timesheet;
    this.currentIndex = index;
  }

  removeAllTimesheets() {
    this.timesheetService.deleteAll()
      .subscribe(
        response => {
          console.log(response);
          this.retrieveTimesheets();
        },
        error => {
          console.log(error);
        });
  }

  searchProjectname() {
    this.timesheetService.findByProjectname(this.projectname)
      .subscribe(
        data => {
          this.timesheets = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
      }
  


}
