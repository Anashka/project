import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logined-page',
  templateUrl: './logined-page.component.html',
  styleUrls: ['./logined-page.component.css']
})
export class LoginedPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
