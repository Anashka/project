import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginedPageComponent } from './logined-page.component';

describe('LoginedPageComponent', () => {
  let component: LoginedPageComponent;
  let fixture: ComponentFixture<LoginedPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginedPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginedPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
