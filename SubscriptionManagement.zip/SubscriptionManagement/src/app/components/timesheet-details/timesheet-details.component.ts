import { Component, OnInit } from '@angular/core';
import { TimesheetService } from 'src/app/services/timesheet.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-timesheet-details',
  templateUrl: './timesheet-details.component.html',
  styleUrls: ['./timesheet-details.component.css']
})
export class TimesheetDetailsComponent implements OnInit {

  currentTimesheet = null;
  message = '';


  constructor(
    private timesheetService: TimesheetService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.message = '';
    this.getTimesheet(this.route.snapshot.paramMap.get('id'));
  }

  getTimesheet(id) {
    this.timesheetService.get(id)
      .subscribe(
        data => {
          this.currentTimesheet = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }



  updateTimesheet() {
    this.timesheetService.update(this.currentTimesheet.id, this.currentTimesheet)
      .subscribe(
        response => {
          console.log(response);
          this.message = 'The Timesheet was updated successfully!';
        },
        error => {
          console.log(error);
        });
  }

  deleteTimesheet() {
    this.timesheetService.delete(this.currentTimesheet.id)
      .subscribe(
        response => {
          console.log(response);
          this.router.navigate(['/timesheets']);
        },
        error => {
          console.log(error);
        });
  }


}
