import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee = {
    firstname: '',
    lastname: '',
    emailid: '',
    phno:''
  };
  submitted = false;

  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
  }

  saveEmployee() {
    const data = {
      firstname: this.employee.firstname,
      lastname:this.employee.lastname,
      emailid:this.employee.emailid,
      phno:this.employee.phno
    };

    this.employeeService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newEmployee() {
    this.submitted = false;
    this.employee = {
    
      firstname:'',
      lastname:'',
      emailid:'',
      phno:''

    };
  }

}
