import { Component, OnInit } from '@angular/core';
import { TimesheetService } from 'src/app/services/timesheet.service';

@Component({
  selector: 'app-add-timesheet',
  templateUrl: './add-timesheet.component.html',
  styleUrls: ['./add-timesheet.component.css']
})
export class AddTimesheetComponent implements OnInit {

  timesheet = {
    projectname: '',
    status: '',
    plannedeffort: '',
    loggedeffort:'',
    billablehours:''
  };
  submitted = false;

  constructor(private timesheetService: TimesheetService) { }

  ngOnInit(): void {
  }

  saveTimesheet() {
    const data = {
      projectname: this.timesheet.projectname,
      status:this.timesheet.status,
      plannedeffort:this.timesheet.plannedeffort,
      loggedeffort:this.timesheet.loggedeffort,
      billablehours:this.timesheet.billablehours
    };

    this.timesheetService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newTimesheet() {
    this.submitted = false;
    this.timesheet = {
    
      projectname:'',
      status:'',
      plannedeffort:'',
      loggedeffort:'',
      billablehours:''

    };
  }

}
