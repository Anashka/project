import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  project = {
    projectname: '',
    projecttype: '',
    plannedenddate: '',
    executioncenter:''
  };
  submitted = false;

  constructor(private projectService: ProjectService) { }

  ngOnInit(): void {
  }

  saveProject() {
    const data = {
      projectname: this.project.projectname,
      projecttype:this.project.projecttype,
      plannedenddate:this.project.plannedenddate,
      executioncenter:this.project.executioncenter
    };

    this.projectService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newProject() {
    this.submitted = false;
    this.project = {
    
      projectname:'',
      projecttype:'',
      plannedenddate:'',
      executioncenter:''

    };
  }


}
