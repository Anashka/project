import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { map } from 'rxjs/operators';
//import { EmployeeService } from './employee.service';

export class User{
  constructor(
    public status:string,
     ) {}
  
}

export class JwtResponse{
  constructor(
    public jwttoken:string,
     ) {}
  
}

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private http:HttpClient
  ) { 
     }
     

     authenticate(username, password) {
      return this.http.post<any>('http://localhost:8762/authenticate',{username,password}).pipe(
       map(
         userData => {
          sessionStorage.setItem('username',username);
          let tokenStr= 'Bearer '+userData.token;
         console.log(tokenStr);
          sessionStorage.setItem('token', tokenStr);
          return userData;
         }
       )
  
      );
    }

    /*public getAll(){
      let tokenStr=  sessionStorage.getItem('token')
      console.log(tokenStr);
      const headers = new HttpHeaders().set("Authorization",tokenStr);
      return this.http.get("http://localhost:8762/employee/api/employees",{headers, responseType : 'text' as 'json'})
      

    }*/
  

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    //console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}