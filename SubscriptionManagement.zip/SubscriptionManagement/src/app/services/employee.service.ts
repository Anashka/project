import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

//const baseUrl = 'http://localhost:8081/api/employees';
const baseUrl = 'http://localhost:8762/employee/api/employees';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  getAll() {
    let tokenStr=  sessionStorage.getItem('token')
    console.log(tokenStr);
    //const headers = new HttpHeaders().set('authorization',tokenStr);
    
    //console.log(headers);
    return this.http.get(baseUrl,{responseType : 'text' as 'json'});
   //return this.http.get(baseUrl,{ headers: headers });
  }

  get(id) {
   // let tokenStr=  sessionStorage.getItem('token')
    //console.log(tokenStr);
    //const headers = new HttpHeaders().set("Authorization",tokenStr);
    return this.http.get(`${baseUrl}/${id}`,{responseType : 'text' as 'json'});
  }

  create(data) {
    //let tokenStr=  sessionStorage.getItem('token')
    //console.log(tokenStr);
   // const headers = new HttpHeaders().set("Authorization",tokenStr);
   // headers.set("Content-Type","application/json");
    return this.http.post(baseUrl, data,{ responseType : 'text' as 'json'});
   // return this.http.post(baseUrl, data,{headers});
  }

  update(id, data) {
   // let tokenStr=  sessionStorage.getItem('token')
  //  console.log(tokenStr);
   // const headers = new HttpHeaders().set("Authorization",tokenStr);
    return this.http.put(`${baseUrl}/${id}`, data,{responseType : 'text' as 'json'});
  }

  delete(id) {
   // let tokenStr=  sessionStorage.getItem('token')
   // console.log(tokenStr);
   // const headers = new HttpHeaders().set("Authorization",tokenStr);
    return this.http.delete(`${baseUrl}/${id}`,{responseType : 'text' as 'json'});
  }

  deleteAll() {
   // let tokenStr=  sessionStorage.getItem('token')
    //console.log(tokenStr);
    //const headers = new HttpHeaders().set("Authorization",tokenStr);
    return this.http.delete(baseUrl,{responseType : 'text' as 'json'});
  }

  findByFirstname(firstname) {
  //  let tokenStr=  sessionStorage.getItem('token')
    //console.log(tokenStr);
    //const headers = new HttpHeaders().set("Authorization",tokenStr);
    return this.http.get(`${baseUrl}?firstname=${firstname}`,{responseType : 'text' as 'json'});
  }
}