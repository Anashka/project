import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginPageComponent } from './components/login-page/login-page.component';
import { LoginedPageComponent } from './components/logined-page/logined-page.component';

import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';
import { EmployeesListComponent } from './components/employees-list/employees-list.component';

import { AddProjectComponent } from './components/add-project/add-project.component';
import { ProjectDetailsComponent } from './components/project-details/project-details.component';
import { ProjectsListComponent } from './components/projects-list/projects-list.component';

import { AddTimesheetComponent } from './components/add-timesheet/add-timesheet.component';
import { TimesheetDetailsComponent } from './components/timesheet-details/timesheet-details.component';
import { TimesheetsListComponent } from './components/timesheets-list/timesheets-list.component';

import { ContactsComponent } from './components/contacts/contacts.component';
import { from } from 'rxjs';
import { AuthGaurdService } from './services/auth-guard.service';

const routes: Routes = [

 
  { path: 'login', component: LoginPageComponent },
  { path: 'logined', component: LoginedPageComponent, canActivate:[AuthGaurdService] },
  {path: 'contacts', component: ContactsComponent },
  {path: 'pricing', component: LoginedPageComponent} ,
  

  
  { path: 'logined/employees', component: EmployeesListComponent},
  { path: 'logined/employees/:id', component: EmployeeDetailsComponent, canActivate:[AuthGaurdService]},
  { path: 'logined/addEmployee', component: AddEmployeeComponent, canActivate:[AuthGaurdService]},

  
  { path: 'logined/projects', component: ProjectsListComponent, canActivate:[AuthGaurdService]},
  { path: 'logined/projects/:id', component: ProjectDetailsComponent, canActivate:[AuthGaurdService]},
  { path: 'logined/addProject', component: AddProjectComponent, canActivate:[AuthGaurdService]},

  //{ path: '', redirectTo: 'timesheets', pathMatch: 'full' },
  { path: 'logined/timesheets', component: TimesheetsListComponent, canActivate:[AuthGaurdService]},
  { path: 'logined/timesheets/:id', component: TimesheetDetailsComponent, canActivate:[AuthGaurdService]},
  { path: 'logined/addTimesheet', component: AddTimesheetComponent, canActivate:[AuthGaurdService]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
