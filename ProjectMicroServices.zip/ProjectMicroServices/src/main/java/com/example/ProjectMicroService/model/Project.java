package com.example.ProjectMicroService.model;

import javax.persistence.*;

@Entity
@Table(name = "projects")
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "projectname")
	private String projectname;

	@Column(name = "projecttype")
	private String projecttype;

	@Column(name = "plannedenddate")
    private String plannedenddate;
    
    @Column(name = "executioncenter")
	private String executioncenter;

	public Project() {

	}

	public Project(String projectname, String projecttype, String plannedenddate, String executioncenter) {
        this.projectname = projectname;
        this.projecttype = projecttype;
        this.plannedenddate = plannedenddate;
        this.executioncenter = executioncenter;
	}

	public long getId() {
		return id;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
    }
    
    public String getProjecttype() {
		return projecttype;
	}

	public void setProjecttype(String projecttype) {
		this.projecttype = projecttype;
    }
    
    public String getPlannedenddate() {
		return plannedenddate;
	}

	public void setPlannedenddate(String plannedenddate) {
		this.plannedenddate = plannedenddate;
    }
    
    public String getExecutioncenter() {
		return executioncenter;
	}

	public void setExecutioncenter(String executioncenter) {
		this.executioncenter = executioncenter;
	}

	

	@Override
	public String toString() {
		return "Project [id=" + id + ", projectname=" + projectname + ",projecttype=" + projecttype + ",plannedenddate=" + plannedenddate + ", executioncenter =" + executioncenter + " ]";
	}
}