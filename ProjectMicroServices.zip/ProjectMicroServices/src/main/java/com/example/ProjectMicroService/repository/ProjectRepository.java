package com.example.ProjectMicroService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ProjectMicroService.model.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {
  //List<Employee> findByPublished(boolean published);
  List<Project> findByProjectnameContaining(String projectname);
}